<!-- <link rel="stylesheet" type="text/css" href="vendor/slick/slick.min.css" />
<link rel="stylesheet" type="text/css" href="vendor/slick/slick-theme.min.css" /> -->
<link href="<?=BASE_URL?>vendor/icons/feather.css" rel="stylesheet" type="text/css">
<link href="<?=BASE_URL?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?=BASE_URL?>css/style.css" rel="stylesheet">
<link href="<?=BASE_URL?>css/owl.carousel.min.css" rel="stylesheet">
<script src="<?=BASE_URL?>vendor/jquery/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
<link href="<?=BASE_URL?>css/custom.css" rel="stylesheet">
<!--<link rel="stylesheet" href="<?=BASE_URL?>css/flickity.css">-->
<script src="<?=BASE_URL?>js/owl.carousel.js"></script>
<link href="<?=BASE_URL?>vendor/sidebar/demo.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.15.7/sweetalert2.min.css" integrity="sha512-qZl4JQ3EiQuvTo3ccVPELbEdBQToJs6T40BSBYHBHGJUpf2f7J4DuOIRzREH9v8OguLY3SgFHULfF+Kf4wGRxw==" crossorigin="anonymous" />


