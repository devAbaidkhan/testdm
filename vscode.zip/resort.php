

<!DOCTYPE html>

<html lang="en">



<head>



    <!-- include cssfiles -->

    <?php include 'includes/meta-tags.php'; ?>



    <!-- include cssfiles -->

    <?php include 'includes/csslinks.php'; ?>







</head>



<body class="margin0" id="body">



    <!-- include header -->

    <?php include 'includes/header.php'; ?>



    <!-- end of navbar -->

    <!-- for mobile screen -->





    <div class="margin-top-75">

        <div class="container">

            <!--<div class="row">-->

            <!--    <div class="col-12">-->

            <!--        <div class="text-white mt-4">-->

            <!--            <div class="input-group rounded shadow-sm overflow-hidden">-->

            <!--                <div class="input-group-prepend">-->

            <!--                    <button class="border-0 btn btn-outline-secondary text-dark bg-white btn-block"><i-->

            <!--                            class="feather-search"></i></button>-->

            <!--                </div>-->

            <!--                <input type="text" class="shadow-none border-0 form-control"-->

            <!--                    placeholder="Search for restaurants or dishes">-->

            <!--            </div>-->

            <!--        </div>-->

            <!--    </div>-->

            <!--</div>-->

        </div>

    </div>

    <!--<div class="container top-carosal">-->

    <!--    <div class="carousel" data-flickity='{ "contain": true,"wrapAround": true }'>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Coffee.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Coffee</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Steak.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Steak</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/ColaCan.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Colacan</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Breakfast.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Breakfast</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Salad.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Salad</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--        <div class="carousel-cell1">-->

    <!--            <div class="dish-category">-->

    <!--                <div class="dish-category-head text-center">-->

    <!--                    <img src="img/icons/Fries.png" class="img-fluid">-->

    <!--                    <p class="text-center font-weight-bold pt-2"><span>Fries</span></p>-->

    <!--                </div>-->

    <!--            </div>-->

    <!--        </div>-->

    <!--    </div>-->

    <!--</div>-->

    

    



    <div class="container">

        

        <section>

        <div class="pt-4 pb-2 title d-flex align-items-center">

            <h5 class="m-0">Recommended for you</h5>

            <!-- <a class="font-weight-bold ml-auto" href="trending.html">View all <i class="feather-chevrons-right"></i></a> -->

        </div>

      <div class="container">

        <div class="row py-3">

          <div class="owl-carousel owl-theme" id="owl-small-1">

            <?php
            $cam_res= campaignsList();
            while($row=mysqli_fetch_array($cam_res)){
                ?>
                    <div class="item">

                    <div class="card">

                    <a href="<?=BASE_URL.'campaigns/'.$row['id']?>">
                        <img class="card-img-top" src="<?=__ImageURL__.$row['banner']?>" alt="Card image cap">
                    </a>

                    </div>

                    </div>
                <?php
            }
            ?>
            
          </div>

         

          

          

        </div>

      </div>

    </section>
    
    <section>
        <div class="pt-4 pb-2 title d-flex align-items-center">
            <h5 class="m-0">Select from Category</h5>
        </div>

      <div class="container">
            <div class="row py-3">
                <div class="owl-carousel owl-carousel-1 owl-theme" id="owl-small-2">

            <?php
            $cam_res= campaignsList();
            while($row=mysqli_fetch_array($cam_res)){
                ?>
                    <div class="item">

                    <div class="card">

                    <a href="<?=BASE_URL.'campaigns/'.$row['id']?>">
                        <img class="card-img-top" src="<?=__ImageURL__.$row['banner']?>" alt="Card image cap">
                    </a>

                    </div>

                    </div>
                <?php
            }
            ?>
            
          </div>

        </div>

      </div>

    </section>



        <div class="py-3 title d-flex align-items-center">

            <h5 class="m-0">All restaurants</h5>

            <!-- <a class="font-weight-bold ml-auto" href="most_popular.html">26 places <i class="feather-chevrons-right"></i></a> -->

        </div>



        <div class="most_popular">

            <div class="row">

            <?php 

            /* echo '<pre>';

            print_r($_SESSION);

            echo '</pre>'; */

          $lat=  $_SESSION['lat'];

         $lng=  $_SESSION['lng'];

         if (isset($_SESSION['lat']) && $_SESSION['lng']) {

             $q="SELECT * FROM (

                SELECT *, 

                    (

                        (

                            (

                                acos(

                                    sin((31.5161532 * pi() / 180))

                                    *

                                    sin(( `lat` * pi() / 180)) + cos(( 31.5161532 * pi() /180 ))

                                    *

                                    cos(( `lat` * pi() / 180)) * cos((( 74.3427561 - `lng`) * pi()/180)))

                            ) * 180/pi()

                        ) * 60 * 1.1515 * 1.609344

                    )

                as distance FROM `vendor`

            ) vendor

            WHERE distance <= 20 and vendor_category_id=2

            LIMIT 15";

         }else

         {

             $q="SELECT * FROM `vendor` WHERE vendor_category_id=2 LIMIT 15";

         }

          $res=  GetDataTable($q);

          while ($row=mysqli_fetch_array($res)) {

         $vendor_id=   urlencode(base64_encode($row['vendor_id']));
         $cityadmin=cityadmin_detail($row['cityadmin_id']);
       $delivery_charges=  $row['delivery_charges']!='' || $row['delivery_charges']!=0 ? $row['delivery_charges'].' '.$cityadmin['currency']:'Free';

              ?>

                <div class="col-md-3 pb-3">

                    <div class="list-card bg-white h-100 rounded overflow-hidden position-relative shadow-sm">

                        <div class="list-card-image">

                            <div class="member-plan position-absolute"><span

                                    class="badge badge-dedo-deals"><?=$row['estimated_delivery_time']?></span></div>


                            <a href="<?=BASE_URL?>restaurant/<?=$row['slug']?>">

                                <img alt="#" src="<?=__ImageURL__.$row['main_image']?>"  class="img-fluid item-img w-100 loading">

                            </a>

                        </div>

                        <div class="p-3 padding-rest-name position-relative">

                            <div class="list-card-body">

                                <h6 class="mb-1 flex-parent" style="display: flex;align-items: center;">

                                    <div class="flex-child long-and-truncated" style="flex: 1;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width:150px;">

                                    <a href="<?=BASE_URL?>restaurant/<?=$row['slug']?>" class="text-black"><?=$row['vendor_name']?> </a>

                                    </div>

                                    <a href="#" class="res_rating"><?=$row['avg_cost_meal']?> </a>

                                </h6>

                                

                                <p class="text-gray mb-1 small"> <?=$row['keywords']!='' ? ' '.$row['keywords'] : ''?></p>

                                 <!--<p class="text-gray mb-1 small"><i class="fa fa-motorcycle"></i> <?=$row['estimated_delivery_time']?> minutes</p>-->

                                 <p class="text-gray mb-1 small"></p>

                                <p class="dim-text rest-rating"><span class="badge badge-success"><!-- <i

                                            class="feather-star"></i> 3.1</span>(1589) --></p>

                            </div>

                            <div class="list-card-badge">

                                 <span class="dfee">Delivery <?=$delivery_charges?></span>

                                 <span class="drate"><i class="feather-star"></i> 3.1 (2.4k)</span>

                            </div>

                        </div>

                    </div>

                </div>

<?php  }?>


            </div>



            



        </div>



    </div>



    <?php



if (!isset($_SESSION['source']) || $_SESSION['source']!='mobile') {

    include_once 'includes/footer.php';

}

?>



    <?php include 'includes/side-menu.php';?>



    <?php include_once 'includes/jslinks.php';?>





    <script>

        function openNav() {

            document.getElementById("mySidenav").style.width = "280px";

            // document.getElementById("body").style.backgroundColor = "red";



        }



        function closeNav() {

            document.getElementById("mySidenav").style.width = "0";

        }

    </script>

    

    <script>

            $(document).ready(function() {

              var owl = $('#owl-small-1');

              owl.owlCarousel({

                margin: 10,

                nav: false,

                loop: true,

                responsive: {

                  0: {

                    items: 1.3

                  },

                  768: {

                    items: 2.2

                  },

                  1000: {

                    items: 3.2

                  },

                  1200: {

                    items: 4

                  }

                }

              })

            })

          </script>
            
            <script>

            $(document).ready(function() {

              var owl = $('#owl-small-2');

              owl.owlCarousel({

                margin: 10,

                nav: false,

                loop: true,

                responsive: {

                  0: {

                    items: 3.8

                  },

                  768: {

                    items: 4

                  },

                  1000: {

                    items: 3.2

                  },

                  1200: {

                    items: 4

                  }

                }

              })

            })

          </script>
          

          <script type="text/javascript">

    	$('img').load(function(){

		   $(this).css('background','none');

		});

    </script>

</body>



</html>