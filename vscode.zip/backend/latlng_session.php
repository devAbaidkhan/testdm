<?php 
include "../protected/config.php";
/* echo '<pre>';
print_r($_POST);
echo '</pre>';
exit; */
$_SESSION['lat']=$_POST['lat'];
$_SESSION['lng']=$_POST['lng'];
?>