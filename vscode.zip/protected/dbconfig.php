<?php
define('DB_DRIVER',  'MySQL');
define('DB_HOST',  'localhost');
define('DB_CHARSET',  '');
define('DB_COLLATION',  '');
define('DB_NAME',  'dedo_testing');
define('DB_USER',  'dedo_testing');
define('DB_PASSWORD',  'dedo_testing786');
?>