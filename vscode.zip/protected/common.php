<?php


define('VERSION','0.0.1');
define('APPNAME','MOS');
define('APPTITLE',  'Mobile Ordering System');
define('RELEASE_DATE','01 JAN 2019');

define('AUTHOR','Muhammad Ali');
define('AUTHOREMAIL', 'a4alig@hotmail.co.uk');
define('COMPANY', 'KtechZ SOLUTIONS');





?>
