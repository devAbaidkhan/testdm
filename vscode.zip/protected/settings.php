<?php
define('_DATE_FORMAT_', date('Y-m-d H:i:s'));
?>