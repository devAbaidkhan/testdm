<?php

define('BASE_URL','https://dedodelivery.com/testdm/');
define('__ImageURL__','https://dedodelivery.com/dedo_testing/');

// define('BASE_URL','https://localhost/dm/');
// define('__ImageURL__','https://dedo/');


?>